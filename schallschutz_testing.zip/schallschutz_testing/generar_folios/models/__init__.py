# -*- coding: utf-8 -*-

from . import core_generar_folio
from . import core_folios