# -*- encoding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from.import purchase_order_confirm
from.import inherit_purchase_requisition
from.import purchase_order





