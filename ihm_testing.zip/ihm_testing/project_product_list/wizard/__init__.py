# -*- coding: utf-8 -*-

from . import delete_rfq
from . import stock_quant_transfer


