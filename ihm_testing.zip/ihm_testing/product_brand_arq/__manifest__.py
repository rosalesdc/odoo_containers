# -*- coding: utf-8 -*-
{
    'name': "Marca y modelo para productos",
    'description': """
        Asignar un tipo de marcar y modelo para los productos
    """,
    'author': "Soluciones4G",
    'website': "http://www.soluciones4g.com",
    'version': '0.1',
    'depends': ['product'],
    'data': ['views/product_brand_view.xml',
        'security/ir.model.access.csv'
        ],
    'installable':True,
    'auto_install':False,
}
