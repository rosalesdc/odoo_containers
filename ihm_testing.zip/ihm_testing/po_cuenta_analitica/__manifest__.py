{
    'name' : "Cuenta Analitica en Orden de Compra",
    'version' : "1.0",
    'description' : "Agrega campo con relacion a las cuentas analiticas en orden de compra",
    'author' : "Soluciones4g", 
    'depends' : ['purchase','account','analytic'],
    'data': ['views/cuenta_analitica.xml'],
    'installable' : True,
}
