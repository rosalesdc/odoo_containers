# -*- coding: utf-8 -*-

from . import po_cuenta_analitica